const take = require("express");
const run = take()

run.get("/say",(req,res) =>{
    res.send("Hello")
})
run.get("/books",(req,res) =>{
    res.send([{name1:"atom",},{name2:"home"},{name3:"devil"},{name4:"monster"}])
})
run.listen(5000, () => {
    console.log("hello")
})